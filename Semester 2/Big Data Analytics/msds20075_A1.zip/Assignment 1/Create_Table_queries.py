# DROP TABLES
# Write queries to drop each table, please don't change variable names,
# You should write respective queries against each varibale

Videoplay_table_drop = "DROP TABLE IF EXISTS Videoplay_fact"
Users_table_drop = "DROP TABLE IF EXISTS Users_dim"
Videos_table_drop = "DROP TABLE IF EXISTS Videos_dim"
Youtubers_table_drop = "DROP TABLE IF EXISTS Youtubers_dim"
Time_table_drop = "DROP TABLE IF EXISTS Time_dim"

# CREATE TABLES
# Write queries to create each table, please don't change variable names, you can refer to star schema table
# You should write respective queries against each varibale

Videoplay_table_create = ("""CREATE TABLE Videoplay_fact
(
    videoplay_id int NOT NULL GENERATED ALWAYS AS IDENTITY ( INCREMENT 1 START 1 ),
    start_time bigint,
    user_id int,
    level varchar,
    video_id varchar,
    youtuber_id varchar,
    session_id int,
    location varchar,
    user_agent varchar,
    PRIMARY KEY (videoplay_id)
);
""")

Users_table_create = ("""CREATE TABLE Users_dim
(
    user_id int NOT NULL,
    first_name varchar,
    last_name varchar,
    gender varchar,
    level varchar,
    PRIMARY KEY (user_id)
);
""")

Videos_table_create = ("""CREATE TABLE Videos_dim
(
    video_id varchar NOT NULL,
    title varchar,
    youtuber_id varchar,
    year int,
    duration numeric,
    PRIMARY KEY (video_id)
);
""")


Youtubers_table_create = ("""CREATE TABLE Youtubers_dim
(
    youtuber_id varchar NOT NULL,
    name varchar,
    location varchar,
    latitude numeric,
    longitude numeric,
    PRIMARY KEY (youtuber_id)
);
""")

Time_table_create = ("""CREATE TABLE Time_dim
(
    start_time  bigint NOT NULL,
    hour  int,
    day  int,
    week  int,
    month  int,
    year  int,
    weekday  int,
    PRIMARY KEY (start_time)
);
""")

# INSERT RECORDS
# Write queries to insert record to each table, please don't change variable names, you can refer to star schema table
# You should write respective queries against each varibale

Videoplay_table_insert = ("""INSERT INTO  Videoplay_fact (start_time,user_id,level,video_id,youtuber_id,session_id,location,user_agent) VALUES (%s,%s,%s,%s,%s,%s,%s,%s) ON CONFLICT (videoplay_id) 
DO 
   NOTHING
""")

Users_table_insert = ("""INSERT INTO  Users_dim (user_id,first_name,last_name,gender,level) VALUES (%s,%s,%s,%s,%s) ON CONFLICT (user_id) 
DO 
   NOTHING
""")

Videos_table_insert = ("""INSERT INTO  Videos_dim (video_id,title,youtuber_id,year,duration) VALUES (%s,%s,%s,%s,%s) ON CONFLICT (video_id) 
DO 
   NOTHING
""")

Youtubers_table_insert = ("""INSERT INTO Youtubers_dim (youtuber_id,name,location,latitude,longitude) VALUES (%s,%s,%s,%s,%s) ON CONFLICT (youtuber_id) 
DO 
  NOTHING;""")


Time_table_insert = ("""INSERT INTO  Time_dim (start_time,hour,day,week,month,year,weekday) VALUES (%s,%s,%s,%s,%s,%s,%s)ON CONFLICT (start_time) 
DO 
  NOTHING;""")

# QUERY LISTS

create_table_queries = [Users_table_create, Time_table_create, Youtubers_table_create, Videos_table_create, Videoplay_table_create]
drop_table_queries = [Videoplay_table_drop, Users_table_drop, Videos_table_drop, Youtubers_table_drop, Time_table_drop]
