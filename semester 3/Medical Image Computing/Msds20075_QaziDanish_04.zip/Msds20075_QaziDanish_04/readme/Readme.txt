﻿ReadME
Try to run the script on google colab
First step is to mount the drive
Then try to add the dataset into your google drive
Using the cd command try to go to the directory to dataset
And then just give the names of the images to stitch the images.
When choosing the images below, make sure that the train image is the image to be transformed.
For the images in the input folder, the image with id 3 should be inverted so that train image is the image B and the query image is image A.